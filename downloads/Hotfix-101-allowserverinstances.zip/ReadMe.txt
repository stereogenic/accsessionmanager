ACC Session Manager would kill all accserver.exe instances upon boot.


Replace the rotate.js in the /bin folder to allow other servers to be run onthe same system.